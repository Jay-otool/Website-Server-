gdjs.city_321Code = {};
gdjs.city_321Code.GDNewSpriteObjects1= [];
gdjs.city_321Code.GDNewSpriteObjects2= [];
gdjs.city_321Code.GDNewSprite3Objects1= [];
gdjs.city_321Code.GDNewSprite3Objects2= [];
gdjs.city_321Code.GDNewSprite2Objects1= [];
gdjs.city_321Code.GDNewSprite2Objects2= [];
gdjs.city_321Code.GDNewSprite4Objects1= [];
gdjs.city_321Code.GDNewSprite4Objects2= [];
gdjs.city_321Code.GDNewSprite5Objects1= [];
gdjs.city_321Code.GDNewSprite5Objects2= [];
gdjs.city_321Code.GDNewTiledSpriteObjects1= [];
gdjs.city_321Code.GDNewTiledSpriteObjects2= [];
gdjs.city_321Code.GDNewSprite6Objects1= [];
gdjs.city_321Code.GDNewSprite6Objects2= [];
gdjs.city_321Code.GDNewSprite7Objects1= [];
gdjs.city_321Code.GDNewSprite7Objects2= [];


gdjs.city_321Code.mapOfGDgdjs_9546city_9595321Code_9546GDNewSprite3Objects1Objects = Hashtable.newFrom({"NewSprite3": gdjs.city_321Code.GDNewSprite3Objects1});
gdjs.city_321Code.mapOfGDgdjs_9546city_9595321Code_9546GDNewSprite4Objects1Objects = Hashtable.newFrom({"NewSprite4": gdjs.city_321Code.GDNewSprite4Objects1});
gdjs.city_321Code.mapOfGDgdjs_9546city_9595321Code_9546GDNewSprite4Objects1Objects = Hashtable.newFrom({"NewSprite4": gdjs.city_321Code.GDNewSprite4Objects1});
gdjs.city_321Code.mapOfGDgdjs_9546city_9595321Code_9546GDNewSprite3Objects1Objects = Hashtable.newFrom({"NewSprite3": gdjs.city_321Code.GDNewSprite3Objects1});
gdjs.city_321Code.mapOfGDgdjs_9546city_9595321Code_9546GDNewSprite2Objects1Objects = Hashtable.newFrom({"NewSprite2": gdjs.city_321Code.GDNewSprite2Objects1});
gdjs.city_321Code.mapOfGDgdjs_9546city_9595321Code_9546GDNewSprite5Objects1Objects = Hashtable.newFrom({"NewSprite5": gdjs.city_321Code.GDNewSprite5Objects1});
gdjs.city_321Code.mapOfGDgdjs_9546city_9595321Code_9546GDNewTiledSpriteObjects1Objects = Hashtable.newFrom({"NewTiledSprite": gdjs.city_321Code.GDNewTiledSpriteObjects1});
gdjs.city_321Code.mapOfGDgdjs_9546city_9595321Code_9546GDNewSprite5Objects1Objects = Hashtable.newFrom({"NewSprite5": gdjs.city_321Code.GDNewSprite5Objects1});
gdjs.city_321Code.mapOfGDgdjs_9546city_9595321Code_9546GDNewSprite4Objects1Objects = Hashtable.newFrom({"NewSprite4": gdjs.city_321Code.GDNewSprite4Objects1});
gdjs.city_321Code.mapOfGDgdjs_9546city_9595321Code_9546GDNewSprite6Objects1Objects = Hashtable.newFrom({"NewSprite6": gdjs.city_321Code.GDNewSprite6Objects1});
gdjs.city_321Code.mapOfGDgdjs_9546city_9595321Code_9546GDNewSprite4Objects1Objects = Hashtable.newFrom({"NewSprite4": gdjs.city_321Code.GDNewSprite4Objects1});
gdjs.city_321Code.mapOfGDgdjs_9546city_9595321Code_9546GDNewSprite6Objects1Objects = Hashtable.newFrom({"NewSprite6": gdjs.city_321Code.GDNewSprite6Objects1});
gdjs.city_321Code.mapOfGDgdjs_9546city_9595321Code_9546GDNewTiledSpriteObjects1Objects = Hashtable.newFrom({"NewTiledSprite": gdjs.city_321Code.GDNewTiledSpriteObjects1});
gdjs.city_321Code.mapOfGDgdjs_9546city_9595321Code_9546GDNewSprite6Objects1Objects = Hashtable.newFrom({"NewSprite6": gdjs.city_321Code.GDNewSprite6Objects1});
gdjs.city_321Code.mapOfGDgdjs_9546city_9595321Code_9546GDNewSprite3Objects1Objects = Hashtable.newFrom({"NewSprite3": gdjs.city_321Code.GDNewSprite3Objects1});
gdjs.city_321Code.mapOfGDgdjs_9546city_9595321Code_9546GDNewSprite6Objects1Objects = Hashtable.newFrom({"NewSprite6": gdjs.city_321Code.GDNewSprite6Objects1});
gdjs.city_321Code.mapOfGDgdjs_9546city_9595321Code_9546GDNewSprite3Objects1Objects = Hashtable.newFrom({"NewSprite3": gdjs.city_321Code.GDNewSprite3Objects1});
gdjs.city_321Code.mapOfGDgdjs_9546city_9595321Code_9546GDNewSprite3Objects1Objects = Hashtable.newFrom({"NewSprite3": gdjs.city_321Code.GDNewSprite3Objects1});
gdjs.city_321Code.mapOfGDgdjs_9546city_9595321Code_9546GDNewSprite6Objects1Objects = Hashtable.newFrom({"NewSprite6": gdjs.city_321Code.GDNewSprite6Objects1});
gdjs.city_321Code.asyncCallback13684676 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Dakota Side 1", false);
}}
gdjs.city_321Code.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.city_321Code.asyncCallback13684676(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.city_321Code.mapOfGDgdjs_9546city_9595321Code_9546GDNewSprite3Objects1Objects = Hashtable.newFrom({"NewSprite3": gdjs.city_321Code.GDNewSprite3Objects1});
gdjs.city_321Code.mapOfGDgdjs_9546city_9595321Code_9546GDNewSprite6Objects1Objects = Hashtable.newFrom({"NewSprite6": gdjs.city_321Code.GDNewSprite6Objects1});
gdjs.city_321Code.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "d");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite3"), gdjs.city_321Code.GDNewSprite3Objects1);
{for(var i = 0, len = gdjs.city_321Code.GDNewSprite3Objects1.length ;i < len;++i) {
    gdjs.city_321Code.GDNewSprite3Objects1[i].getBehavior("Animation").setAnimationName("Idle 2");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite3"), gdjs.city_321Code.GDNewSprite3Objects1);
{for(var i = 0, len = gdjs.city_321Code.GDNewSprite3Objects1.length ;i < len;++i) {
    gdjs.city_321Code.GDNewSprite3Objects1[i].getBehavior("Animation").setAnimationName("Walk 2");
}
}{for(var i = 0, len = gdjs.city_321Code.GDNewSprite3Objects1.length ;i < len;++i) {
    gdjs.city_321Code.GDNewSprite3Objects1[i].addForce(30, 0, 0);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "a");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite3"), gdjs.city_321Code.GDNewSprite3Objects1);
{for(var i = 0, len = gdjs.city_321Code.GDNewSprite3Objects1.length ;i < len;++i) {
    gdjs.city_321Code.GDNewSprite3Objects1[i].getBehavior("Animation").setAnimationName("Idle 1");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite3"), gdjs.city_321Code.GDNewSprite3Objects1);
{for(var i = 0, len = gdjs.city_321Code.GDNewSprite3Objects1.length ;i < len;++i) {
    gdjs.city_321Code.GDNewSprite3Objects1[i].getBehavior("Animation").setAnimationName("Walk 1");
}
}{for(var i = 0, len = gdjs.city_321Code.GDNewSprite3Objects1.length ;i < len;++i) {
    gdjs.city_321Code.GDNewSprite3Objects1[i].addForce(-(30), 0, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite3"), gdjs.city_321Code.GDNewSprite3Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite4"), gdjs.city_321Code.GDNewSprite4Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.city_321Code.mapOfGDgdjs_9546city_9595321Code_9546GDNewSprite3Objects1Objects, gdjs.city_321Code.mapOfGDgdjs_9546city_9595321Code_9546GDNewSprite4Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.city_321Code.GDNewSprite3Objects1 */
/* Reuse gdjs.city_321Code.GDNewSprite4Objects1 */
{for(var i = 0, len = gdjs.city_321Code.GDNewSprite3Objects1.length ;i < len;++i) {
    gdjs.city_321Code.GDNewSprite3Objects1[i].separateFromObjectsList(gdjs.city_321Code.mapOfGDgdjs_9546city_9595321Code_9546GDNewSprite4Objects1Objects, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite2"), gdjs.city_321Code.GDNewSprite2Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite3"), gdjs.city_321Code.GDNewSprite3Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.city_321Code.mapOfGDgdjs_9546city_9595321Code_9546GDNewSprite3Objects1Objects, gdjs.city_321Code.mapOfGDgdjs_9546city_9595321Code_9546GDNewSprite2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Shady valley 1", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite5"), gdjs.city_321Code.GDNewSprite5Objects1);
{for(var i = 0, len = gdjs.city_321Code.GDNewSprite5Objects1.length ;i < len;++i) {
    gdjs.city_321Code.GDNewSprite5Objects1[i].getBehavior("Animation").setAnimationName("WALK 1");
}
}{for(var i = 0, len = gdjs.city_321Code.GDNewSprite5Objects1.length ;i < len;++i) {
    gdjs.city_321Code.GDNewSprite5Objects1[i].addForce(-(60), 0, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite5"), gdjs.city_321Code.GDNewSprite5Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewTiledSprite"), gdjs.city_321Code.GDNewTiledSpriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.city_321Code.mapOfGDgdjs_9546city_9595321Code_9546GDNewSprite5Objects1Objects, gdjs.city_321Code.mapOfGDgdjs_9546city_9595321Code_9546GDNewTiledSpriteObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.city_321Code.GDNewSprite5Objects1 */
{for(var i = 0, len = gdjs.city_321Code.GDNewSprite5Objects1.length ;i < len;++i) {
    gdjs.city_321Code.GDNewSprite5Objects1[i].getBehavior("Animation").setAnimationName("WALK 2");
}
}{for(var i = 0, len = gdjs.city_321Code.GDNewSprite5Objects1.length ;i < len;++i) {
    gdjs.city_321Code.GDNewSprite5Objects1[i].addForce(60, 0, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite4"), gdjs.city_321Code.GDNewSprite4Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite5"), gdjs.city_321Code.GDNewSprite5Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.city_321Code.mapOfGDgdjs_9546city_9595321Code_9546GDNewSprite5Objects1Objects, gdjs.city_321Code.mapOfGDgdjs_9546city_9595321Code_9546GDNewSprite4Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.city_321Code.GDNewSprite5Objects1 */
{for(var i = 0, len = gdjs.city_321Code.GDNewSprite5Objects1.length ;i < len;++i) {
    gdjs.city_321Code.GDNewSprite5Objects1[i].getBehavior("Animation").setAnimationName("WALK 1");
}
}{for(var i = 0, len = gdjs.city_321Code.GDNewSprite5Objects1.length ;i < len;++i) {
    gdjs.city_321Code.GDNewSprite5Objects1[i].addForce(-(60), 0, 1);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite6"), gdjs.city_321Code.GDNewSprite6Objects1);
{for(var i = 0, len = gdjs.city_321Code.GDNewSprite6Objects1.length ;i < len;++i) {
    gdjs.city_321Code.GDNewSprite6Objects1[i].getBehavior("Animation").setAnimationName("run 1");
}
}{for(var i = 0, len = gdjs.city_321Code.GDNewSprite6Objects1.length ;i < len;++i) {
    gdjs.city_321Code.GDNewSprite6Objects1[i].addForce(-(90), 0, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite4"), gdjs.city_321Code.GDNewSprite4Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite6"), gdjs.city_321Code.GDNewSprite6Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.city_321Code.mapOfGDgdjs_9546city_9595321Code_9546GDNewSprite6Objects1Objects, gdjs.city_321Code.mapOfGDgdjs_9546city_9595321Code_9546GDNewSprite4Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.city_321Code.GDNewSprite6Objects1 */
{for(var i = 0, len = gdjs.city_321Code.GDNewSprite6Objects1.length ;i < len;++i) {
    gdjs.city_321Code.GDNewSprite6Objects1[i].getBehavior("Animation").setAnimationName("run 1");
}
}{for(var i = 0, len = gdjs.city_321Code.GDNewSprite6Objects1.length ;i < len;++i) {
    gdjs.city_321Code.GDNewSprite6Objects1[i].addForce(-(90), 0, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite6"), gdjs.city_321Code.GDNewSprite6Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewTiledSprite"), gdjs.city_321Code.GDNewTiledSpriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.city_321Code.mapOfGDgdjs_9546city_9595321Code_9546GDNewSprite6Objects1Objects, gdjs.city_321Code.mapOfGDgdjs_9546city_9595321Code_9546GDNewTiledSpriteObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.city_321Code.GDNewSprite6Objects1 */
{for(var i = 0, len = gdjs.city_321Code.GDNewSprite6Objects1.length ;i < len;++i) {
    gdjs.city_321Code.GDNewSprite6Objects1[i].getBehavior("Animation").setAnimationName("run 2");
}
}{for(var i = 0, len = gdjs.city_321Code.GDNewSprite6Objects1.length ;i < len;++i) {
    gdjs.city_321Code.GDNewSprite6Objects1[i].addForce(90, 0, 1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite3"), gdjs.city_321Code.GDNewSprite3Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite6"), gdjs.city_321Code.GDNewSprite6Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.city_321Code.mapOfGDgdjs_9546city_9595321Code_9546GDNewSprite6Objects1Objects, gdjs.city_321Code.mapOfGDgdjs_9546city_9595321Code_9546GDNewSprite3Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite7"), gdjs.city_321Code.GDNewSprite7Objects1);
{for(var i = 0, len = gdjs.city_321Code.GDNewSprite7Objects1.length ;i < len;++i) {
    gdjs.city_321Code.GDNewSprite7Objects1[i].hide(false);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite7"), gdjs.city_321Code.GDNewSprite7Objects1);
{for(var i = 0, len = gdjs.city_321Code.GDNewSprite7Objects1.length ;i < len;++i) {
    gdjs.city_321Code.GDNewSprite7Objects1[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite3"), gdjs.city_321Code.GDNewSprite3Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite6"), gdjs.city_321Code.GDNewSprite6Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.city_321Code.mapOfGDgdjs_9546city_9595321Code_9546GDNewSprite6Objects1Objects, gdjs.city_321Code.mapOfGDgdjs_9546city_9595321Code_9546GDNewSprite3Objects1Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite7"), gdjs.city_321Code.GDNewSprite7Objects1);
{for(var i = 0, len = gdjs.city_321Code.GDNewSprite7Objects1.length ;i < len;++i) {
    gdjs.city_321Code.GDNewSprite7Objects1[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite3"), gdjs.city_321Code.GDNewSprite3Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite6"), gdjs.city_321Code.GDNewSprite6Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "p");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.city_321Code.mapOfGDgdjs_9546city_9595321Code_9546GDNewSprite3Objects1Objects, gdjs.city_321Code.mapOfGDgdjs_9546city_9595321Code_9546GDNewSprite6Objects1Objects, false, runtimeScene, false);
}
if (isConditionTrue_0) {
/* Reuse gdjs.city_321Code.GDNewSprite3Objects1 */
/* Reuse gdjs.city_321Code.GDNewSprite6Objects1 */
{for(var i = 0, len = gdjs.city_321Code.GDNewSprite6Objects1.length ;i < len;++i) {
    gdjs.city_321Code.GDNewSprite6Objects1[i].getBehavior("Animation").setAnimationName("fell");
}
}{for(var i = 0, len = gdjs.city_321Code.GDNewSprite3Objects1.length ;i < len;++i) {
    gdjs.city_321Code.GDNewSprite3Objects1[i].getBehavior("Animation").setAnimationName("punch");
}
}{gdjs.evtTools.sound.unloadAllAudio(runtimeScene);
}
{ //Subevents
gdjs.city_321Code.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite3"), gdjs.city_321Code.GDNewSprite3Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite6"), gdjs.city_321Code.GDNewSprite6Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.city_321Code.mapOfGDgdjs_9546city_9595321Code_9546GDNewSprite3Objects1Objects, gdjs.city_321Code.mapOfGDgdjs_9546city_9595321Code_9546GDNewSprite6Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13685308);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "Pathetic.mp3", false, 100, 1);
}}

}


};

gdjs.city_321Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.city_321Code.GDNewSpriteObjects1.length = 0;
gdjs.city_321Code.GDNewSpriteObjects2.length = 0;
gdjs.city_321Code.GDNewSprite3Objects1.length = 0;
gdjs.city_321Code.GDNewSprite3Objects2.length = 0;
gdjs.city_321Code.GDNewSprite2Objects1.length = 0;
gdjs.city_321Code.GDNewSprite2Objects2.length = 0;
gdjs.city_321Code.GDNewSprite4Objects1.length = 0;
gdjs.city_321Code.GDNewSprite4Objects2.length = 0;
gdjs.city_321Code.GDNewSprite5Objects1.length = 0;
gdjs.city_321Code.GDNewSprite5Objects2.length = 0;
gdjs.city_321Code.GDNewTiledSpriteObjects1.length = 0;
gdjs.city_321Code.GDNewTiledSpriteObjects2.length = 0;
gdjs.city_321Code.GDNewSprite6Objects1.length = 0;
gdjs.city_321Code.GDNewSprite6Objects2.length = 0;
gdjs.city_321Code.GDNewSprite7Objects1.length = 0;
gdjs.city_321Code.GDNewSprite7Objects2.length = 0;

gdjs.city_321Code.eventsList1(runtimeScene);

return;

}

gdjs['city_321Code'] = gdjs.city_321Code;
